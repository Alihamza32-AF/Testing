GHOST-COPY Native Android APK Project
Developer: Ali Hamza
Powered by: Team x 32™ & AF Cyber Force

What this APK does:
- Starts a persistent Floating Bubble (FloatingBubbleService with START_STICKY).
- Even after you CLOSE GHOST-COPY, the floating bubble stays on your screen.
- Open WhatsApp, WhatsApp Business, Instagram, Chrome, or any app and tap the bubble.
- ScreenOverlayPicker highlights every visible text block on top of that app (or runs ML Kit OCR on images) so you can tap any message or "Copy Channel Posts" immediately.

Option A — Build on Phone Only (NO PC, NO Termux — 100% Free via GitHub Cloud):
1. Keep GHOST-COPY-Android-Studio-Project.zip as ONE single file (do NOT unzip it).
2. Open https://github.com in Chrome on your phone -> sign in -> create a New repository (check "Add a README file").
3. Tap "Add file" -> "Upload files" -> select GHOST-COPY-Android-Studio-Project.zip -> tap "Commit changes".
4. Tap "Add file" -> "Create new file" -> enter filename: .github/workflows/build-apk.yml
5. Paste the workflow YAML from GHOST-COPY (or copy from .github/workflows/build-apk.yml) -> tap "Commit changes".
6. Open the "Actions" tab on GitHub -> wait ~2 minutes -> tap "GHOST-COPY-debug-apk" to download app-debug.apk!

Option B — Build with Android Studio (PC / Mac):
1. Extract this ZIP into a folder named GHOST-COPY.
2. Open Android Studio -> File -> Open -> select that folder (Gradle syncs automatically).
3. Click Build -> Build Bundle(s) / APK(s) -> Build APK(s).

Phone Setup After Installing APK:
1. Install app-debug.apk on your Android phone.
2. Open GHOST-COPY -> tap "1. Start Floating Bubble", "2. Enable Accessibility Service", and "3. Allow Background Running".
3. Close GHOST-COPY and open WhatsApp / WhatsApp Business — tap the floating bubble to copy anything!