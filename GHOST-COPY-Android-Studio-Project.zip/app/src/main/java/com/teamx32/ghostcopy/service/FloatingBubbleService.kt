package com.teamx32.ghostcopy.service

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.ImageButton
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.teamx32.ghostcopy.MainActivity
import com.teamx32.ghostcopy.R

/**
 * Persistent Background Floating Overlay Service
 * Stays active over WhatsApp & other apps even when GHOST-COPY is closed from Recents.
 */
class FloatingBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null

    override fun onCreate() {
        super.onCreate()
        startPersistentNotification()
        attachFloatingBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // START_STICKY tells Android to restart the floating bubble if killed by memory pressure
        return START_STICKY
    }

    private fun startPersistentNotification() {
        val channelId = "ghost_copy_bg_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "GHOST-COPY Floating Engine",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("GHOST-COPY Floating Active")
            .setContentText("Tap bubble over WhatsApp or any app to copy text · Team x 32™")
            .setSmallIcon(R.drawable.ic_ghost_bubble)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(3201, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(3201, notification)
        }
    }

    private fun attachFloatingBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 280
        }

        val button = ImageButton(this).apply {
            setImageResource(R.drawable.ic_ghost_bubble)
            setBackgroundResource(R.drawable.bg_ghost_bubble)
            setPadding(30, 30, 30, 30)
            elevation = 14f
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        button.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX - (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(button, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = Math.abs(event.rawX - initialTouchX) > 12 ||
                                Math.abs(event.rawY - initialTouchY) > 12
                    if (!moved) {
                        val service = GhostAccessibilityService.instance
                        if (service != null) {
                            service.scanActiveScreenAndShowPicker()
                        } else {
                            Toast.makeText(
                                this,
                                "Enable GHOST-COPY in Settings > Accessibility first",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                    true
                }
                else -> false
            }
        }

        bubbleView = button
        windowManager.addView(button, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        bubbleView?.let { windowManager.removeView(it) }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}