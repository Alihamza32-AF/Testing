package com.teamx32.ghostcopy.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout

/**
 * Interactive Universal Copy Overlay
 * Highlights all text blocks over WhatsApp / Chrome / Instagram so user can tap to copy any block.
 */
class ScreenOverlayPicker(private val service: GhostAccessibilityService) {

    private val windowManager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var rootOverlay: FrameLayout? = null

    fun show(nodes: List<CapturedTextNode>, isWhatsApp: Boolean = false) {
        dismiss()

        val container = FrameLayout(service).apply {
            setBackgroundColor(Color.parseColor("#73090B10"))
        }

        // Render tap-to-copy bounding frames directly over WhatsApp / WA Business / any app
        for (node in nodes) {
            val box = View(service).apply {
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#2610B981"))
                    setStroke(3, Color.parseColor("#10B981"))
                    cornerRadius = 14f
                }
                setOnClickListener {
                    service.copyToClipboard(
                        if (isWhatsApp) "GHOST-COPY Channel Post" else "GHOST-COPY Block",
                        node.text
                    )
                    dismiss()
                }
            }

            val lp = FrameLayout.LayoutParams(
                node.bounds.width().coerceAtLeast(48),
                node.bounds.height().coerceAtLeast(48)
            ).apply {
                leftMargin = node.bounds.left
                topMargin = node.bounds.top
            }
            container.addView(box, lp)
        }

        // Bottom Floating Action Bar (Copy All / OCR Shot / Close)
        val actionBar = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(24, 18, 24, 18)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F211151E"))
                setStroke(2, Color.parseColor("#3310B981"))
                cornerRadius = 32f
            }
        }

        val btnCopyAll = Button(service).apply {
            text = if (isWhatsApp) "Copy Channel Posts" else "Copy All"
            setTextColor(Color.parseColor("#052E16"))
            setBackgroundColor(Color.parseColor("#10B981"))
            setOnClickListener {
                val combined = nodes.joinToString("\n\n") { it.text }
                service.copyToClipboard("GHOST-COPY All", combined)
                dismiss()
            }
        }

        val btnOcr = Button(service).apply {
            text = "OCR Shot"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                dismiss()
                service.captureAndOcrCurrentScreen { ocrNodes ->
                    if (ocrNodes.isNotEmpty()) {
                        ScreenOverlayPicker(service).show(ocrNodes, isWhatsApp)
                    }
                }
            }
        }

        val btnClose = Button(service).apply {
            text = "Close"
            setTextColor(Color.parseColor("#CBD5E1"))
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { dismiss() }
        }

        actionBar.addView(btnCopyAll)
        actionBar.addView(btnOcr)
        actionBar.addView(btnClose)

        val barParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply {
            bottomMargin = 72
        }
        container.addView(actionBar, barParams)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        rootOverlay = container
        windowManager.addView(container, params)
    }

    fun dismiss() {
        rootOverlay?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
            rootOverlay = null
        }
    }
}