package com.teamx32.ghostcopy.service

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

data class CapturedTextNode(
    val text: String,
    val bounds: Rect
)

/**
 * GHOST-COPY Background Accessibility Service
 * Developer: Ali Hamza | Powered by Team x 32™ & AF Cyber Force
 * Runs continuously in the background even if the user closes GHOST-COPY from Recents.
 */
class GhostAccessibilityService : AccessibilityService() {

    companion object {
        var instance: GhostAccessibilityService? = null
        val WHATSAPP_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        startForegroundService(Intent(this, FloatingBubbleService::class.java))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Tracks active window seamlessly for WhatsApp, WhatsApp Business & other apps
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    fun isWhatsAppActive(): Boolean {
        val pkg = rootInActiveWindow?.packageName?.toString() ?: return false
        return WHATSAPP_PACKAGES.contains(pkg)
    }

    /**
     * Triggered when user taps the Floating Bubble over WhatsApp, WhatsApp Business, or any app.
     * Filters channel noise when inside WhatsApp and shows ScreenOverlayPicker directly on top.
     */
    fun scanActiveScreenAndShowPicker() {
        val isWhatsApp = isWhatsAppActive()
        val nodes = collectScreenTextNodes(filterWhatsAppNoise = isWhatsApp)
        if (nodes.isNotEmpty()) {
            ScreenOverlayPicker(this).show(nodes, isWhatsApp)
        } else {
            captureAndOcrCurrentScreen { ocrNodes ->
                if (ocrNodes.isNotEmpty()) {
                    ScreenOverlayPicker(this).show(ocrNodes, isWhatsApp)
                } else {
                    Toast.makeText(
                        this,
                        "GHOST-COPY: No readable text found on screen.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    fun collectScreenTextNodes(filterWhatsAppNoise: Boolean = false): List<CapturedTextNode> {
        val rootNode = rootInActiveWindow ?: return emptyList()
        val collected = mutableListOf<CapturedTextNode>()
        val seen = HashSet<String>()
        traverseNodeTree(rootNode, collected, seen, filterWhatsAppNoise)
        return collected
    }

    private fun isWhatsAppUiNoise(value: String): Boolean {
        val trimmed = value.trim()
        if (trimmed.length <= 1) return true
        if (trimmed.matches(Regex("^\d{1,2}:\d{2}(\s?[APap][Mm])?$"))) return true
        if (trimmed.matches(Regex("^\d+(\.\d+)?[KkMm]?$"))) return true
        val blockedLabels = setOf(
            "Follow", "Following", "Forwarded", "Type a message", "Message",
            "Voice message", "Camera", "Attach", "More options", "Search",
            "Back", "Call", "Video call", "Channel info", "Mute notifications"
        )
        return blockedLabels.any { it.equals(trimmed, ignoreCase = true) }
    }

    private fun traverseNodeTree(
        node: AccessibilityNodeInfo?,
        out: MutableList<CapturedTextNode>,
        seen: HashSet<String>,
        filterWhatsAppNoise: Boolean
    ) {
        if (node == null) return
        val rawText = node.text?.toString()?.trim()
        val descText = node.contentDescription?.toString()?.trim()
        val value = when {
            !rawText.isNullOrEmpty() -> rawText
            !descText.isNullOrEmpty() && descText.length > 3 -> descText
            else -> null
        }

        if (value != null && node.isVisibleToUser) {
            if (!filterWhatsAppNoise || !isWhatsAppUiNoise(value)) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                val key = "${rect.left},${rect.top}:$value"
                if (rect.width() > 8 && rect.height() > 8 && seen.add(key)) {
                    out.add(CapturedTextNode(value, rect))
                }
            }
        }

        for (i in 0 until node.childCount) {
            traverseNodeTree(node.getChild(i), out, seen, filterWhatsAppNoise)
        }
    }

    /**
     * Android 11+ Accessibility Screenshot + ML Kit OCR for pictures & unselectable WhatsApp views
     */
    fun captureAndOcrCurrentScreen(onResult: (List<CapturedTextNode>) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            onResult(collectScreenTextNodes())
            return
        }
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            ContextCompat.getMainExecutor(this),
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val hardwareBitmap = Bitmap.wrapHardwareBuffer(
                        screenshot.hardwareBuffer,
                        screenshot.colorSpace
                    )
                    val bitmap = hardwareBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                    screenshot.hardwareBuffer.close()

                    if (bitmap == null) {
                        onResult(emptyList())
                        return
                    }
                    val image = InputImage.fromBitmap(bitmap, 0)
                    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    recognizer.process(image)
                        .addOnSuccessListener { visionText ->
                            val blocks = visionText.textBlocks.mapNotNull { block ->
                                val box = block.boundingBox ?: return@mapNotNull null
                                val txt = block.text.trim()
                                if (txt.isEmpty()) null else CapturedTextNode(txt, box)
                            }
                            onResult(blocks)
                        }
                        .addOnFailureListener {
                            onResult(emptyList())
                        }
                }

                override fun onFailure(errorCode: Int) {
                    onResult(collectScreenTextNodes())
                }
            }
        )
    }

    fun copyToClipboard(label: String, text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(this, "GHOST-COPY: Copied!", Toast.LENGTH_SHORT).show()
    }
}